# Global AI Mahlet — five-feature build

This package is prepared around the five features selected for Global AI Mahlet:

1. Real image understanding
2. User-controlled memory
3. Real analytics instrumentation
4. B2B/business workspace context
5. Real web-search integration point

## Important

The image model uses Cloudflare Workers AI `@cf/google/gemma-4-26b-a4b-it`, which Cloudflare currently lists as a vision model and as available on the Workers Free plan. This avoids the Meta-license agreement required by Llama 3.2 Vision.

The web-search UI/backend endpoint is intentionally honest: it does not fake live web results. A supported provider must be connected through Cloudflare AI Gateway before `/api/search` can return live search results.

Memory and business workspace are user-controlled in the browser and are sent to the Worker only with each relevant chat request.

Analytics are written to Workers Analytics Engine when the binding is deployed. Cloudflare also provides built-in Worker metrics.

## Web Search setup

The web-search button is wired to Cloudflare AI Gateway's OpenAI Responses web-search tool through the Workers AI binding. Cloudflare's current docs show this pattern with `openai/gpt-4o-mini` and `tools: [{ type: "web_search_preview" }]` plus a gateway. A gateway/provider billing setup is required; live third-party web search is not guaranteed to be free.
