interface Env {
  AI: Ai;
  ASSETS: Fetcher;
  ANALYTICS?: AnalyticsEngineDataset;
  AI_GATEWAY_ID?: string;
  SEARCH_MODEL?: string;
}

interface Ai {
  run(model: string, inputs: Record<string, unknown>, options?: Record<string, unknown>): Promise<any>;
}

interface AnalyticsEngineDataset {
  writeDataPoint(data: {
    blobs?: string[];
    doubles?: number[];
    indexes?: string[];
  }): void;
}

interface ChatMessage {
  role?: string;
  content?: string;
  text?: string;
}

interface MemoryItem {
  id?: string;
  text?: string;
}

interface BusinessProfile {
  company?: string;
  role?: string;
  goal?: string;
  tone?: string;
}

interface RequestBody {
  message?: string;
  language?: string;
  image?: string;
  imageName?: string;
  messages?: ChatMessage[];
  memories?: MemoryItem[];
  businessProfile?: BusinessProfile;
  webSearch?: boolean;
  event?: string;
}

const TEXT_MODEL = "@cf/meta/llama-3.1-8b-instruct-fast";
const VISION_MODEL = "@cf/google/gemma-4-26b-a4b-it";

function json(data: unknown, status = 200, corsHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function recordEvent(env: Env, event: string, path: string, ok = true) {
  try {
    env.ANALYTICS?.writeDataPoint({
      indexes: [event.slice(0, 96), path.slice(0, 96)],
      blobs: [ok ? "ok" : "error"],
      doubles: [1],
    });
  } catch (error) {
    console.error("Analytics write failed:", error);
  }
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });

    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(request);

    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, corsHeaders);

    try {
      const body = (await request.json()) as RequestBody;

      if (url.pathname === "/api/analytics") {
        recordEvent(env, String(body.event || "unknown"), url.pathname, true);
        return json({ ok: true }, 200, corsHeaders);
      }

      if (url.pathname === "/api/search") {
        recordEvent(env, "web_search", url.pathname, true);
        return json({
          error: "WEB_SEARCH_NOT_CONFIGURED",
          text: "Web Search is built into Global AI Mahlet, but a web-search provider still needs to be connected in Cloudflare AI Gateway. I will not pretend to search the live web without a real search provider.",
          setup: "Connect a supported web-search provider in Cloudflare AI Gateway, then set AI_GATEWAY_ID and SEARCH_MODEL for this Worker.",
        }, 503, corsHeaders);
      }

      if (url.pathname !== "/api/chat") return json({ error: "Not found" }, 404, corsHeaders);

      const message = String(body.message || "").trim();
      const language = String(body.language || "en");
      const image = typeof body.image === "string" ? body.image : "";
      const webSearch = Boolean(body.webSearch);

      if (!message && !image) return json({ error: "Message or image is required" }, 400, corsHeaders);

      const previousMessages = Array.isArray(body.messages) ? body.messages : [];
      const messages = previousMessages
        .filter((m) => m && (m.content || m.text))
        .slice(-20)
        .map((m) => ({
          role: m.role === "assistant" ? "assistant" : "user",
          content: String(m.content || m.text || ""),
        }));

      if (message) {
        if (!messages.length || messages[messages.length - 1].content !== message) {
          messages.push({ role: "user", content: message });
        }
      } else if (image) {
        messages.push({ role: "user", content: "Please analyze this image and explain what you can actually determine from it." });
      }

      const memories = Array.isArray(body.memories)
        ? body.memories.map((m) => String(m?.text || "").trim()).filter(Boolean).slice(0, 20)
        : [];

      const bp = body.businessProfile || {};
      const businessContext = [
        bp.company ? `Company: ${String(bp.company).slice(0, 200)}` : "",
        bp.role ? `Role: ${String(bp.role).slice(0, 200)}` : "",
        bp.goal ? `Business goal: ${String(bp.goal).slice(0, 500)}` : "",
        bp.tone ? `Preferred business tone: ${String(bp.tone).slice(0, 100)}` : "",
      ].filter(Boolean).join("\n");

      const memoryContext = memories.length
        ? `User-controlled memory (use only when relevant):\n- ${memories.join("\n- ")}`
        : "No saved user memory was provided.";

      const systemPrompt = `
You are Global AI Mahlet, a warm, accurate, multilingual AI assistant.
Help users learn, create, code, solve problems, write, understand information, analyze images, and plan.
The selected language is: ${language}
Respond naturally in that language when appropriate.

${memoryContext}

${businessContext ? `Business workspace context:\n${businessContext}` : "No business workspace context was provided."}

Image rules:
- When an image is provided, actually analyze it.
- Never claim to see details that are not visible.
- If text is visible, extract only text you can actually read.
- If the image is unclear, say what cannot be determined.

Web rules:
- If live web search is not actually available, do not claim that you searched the web.
- Do not invent current facts or sources.
`;

      let result: any;

      if (webSearch && !image) {
        recordEvent(env, "web_search", url.pathname, true);
        result = await env.AI.run(
          "openai/gpt-4o-mini",
          {
            input: [
              {
                role: "system",
                content: systemPrompt + "\nUse live web search for this request. Give a concise answer and do not invent sources.",
              },
              { role: "user", content: message },
            ],
            max_output_tokens: 1024,
            tools: [{ type: "web_search_preview" }],
          },
          { gateway: { id: "default" } }
        );
      } else if (image) {
        recordEvent(env, "image_analysis", url.pathname, true);
        result = await env.AI.run(VISION_MODEL, {
          messages: [
            { role: "system", content: systemPrompt },
            ...messages,
          ],
          image,
          max_completion_tokens: 1024,
          temperature: 0.5,
        });
      } else {
        recordEvent(env, webSearch ? "chat_web_search_requested" : "chat", url.pathname, true);
        result = await env.AI.run(TEXT_MODEL, {
          messages: [
            { role: "system", content: systemPrompt },
            ...messages,
          ],
          max_tokens: 1024,
          temperature: 0.6,
        });
      }

      const answer =
        result?.response ||
        result?.result?.response ||
        result?.choices?.[0]?.message?.content ||
        result?.output_text ||
        result?.result?.output_text;
      if (!answer) throw new Error("Cloudflare AI returned no response");

      return json({
        text: String(answer),
        language,
        imageAnalyzed: Boolean(image),
        webSearchRequested: webSearch,
      }, 200, corsHeaders);
    } catch (error) {
      console.error("Global AI Mahlet Worker error:", error);
      recordEvent(env, "request_error", url.pathname, false);
      return json({
        text: "Global AI Mahlet could not complete that request right now.",
        error: error instanceof Error ? error.message : String(error),
      }, 500, corsHeaders);
    }
  },
};
