interface Env { AI: Ai; ASSETS: Fetcher; }
interface Fetcher { fetch(request: Request): Promise<Response>; }
interface Ai { run(model: string, inputs: Record<string, unknown>): Promise<any>; }
interface ChatMessage { role?: string; content?: string; text?: string; }
interface RequestBody { message?: string; language?: string; image?: string; messages?: ChatMessage[]; webSearch?: boolean; }

function stripHtml(value: string){ return String(value||"").replace(/<[^>]*>/g, " ").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/\\s+/g," ").trim(); }
function decodeUrl(value:string){ try { return decodeURIComponent(value.replace(/&amp;/g,"&")); } catch { return value; } }

async function webSearch(query:string){
  const q=query.trim();
  if(!q)return {context:"",sources:[] as Array<{title:string,url:string}>};
  const sources:Array<{title:string,url:string}>=[]; const contextParts:string[]=[];
  try{
    const response=await fetch("https://html.duckduckgo.com/html/?q="+encodeURIComponent(q),{headers:{"User-Agent":"Mozilla/5.0 (compatible; Global-AI-Mahlet/1.0; +https://global-ai-mahlet.pages.dev/)"}});
    if(response.ok){
      const html=await response.text();
      const blocks=html.match(/<div[^>]*class="result"[\s\S]*?<\/div>\\s*<\/div>/gi)||[];
      for(const block of blocks){
        const link=block.match(/<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i); if(!link)continue;
        const url=decodeUrl(link[1]); if(!/^https?:\/\//i.test(url))continue;
        const title=stripHtml(link[2])||"Web result";
        const snippetMatch=block.match(/<a[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/a>/i)||block.match(/<div[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/div>/i);
        const snippet=snippetMatch?stripHtml(snippetMatch[1]):"";
        if(!sources.some(x=>x.url===url)){ sources.push({title,url}); contextParts.push(`${title}\\n${snippet}\\nSource: ${url}`.trim()); }
        if(sources.length>=6)break;
      }
    }
  }catch(error){ console.warn("DuckDuckGo HTML search failed",error); }
  if(!sources.length){
    try{
      const response=await fetch("https://api.duckduckgo.com/?q="+encodeURIComponent(q)+"&format=json&no_html=1&skip_disambig=1&no_redirect=1",{headers:{"User-Agent":"Global AI Mahlet/1.0"}});
      if(response.ok){
        const data:any=await response.json();
        if(data.AbstractURL&&(data.AbstractText||data.Heading)){sources.push({title:data.Heading||"Web result",url:data.AbstractURL});contextParts.push(`${data.Heading||"Web result"}\\n${data.AbstractText||""}\\nSource: ${data.AbstractURL}`.trim());}
        for(const item of Array.isArray(data.RelatedTopics)?data.RelatedTopics:[]){ if(item?.FirstURL&&item?.Text&&sources.length<6){sources.push({title:stripHtml(item.Text).slice(0,180),url:item.FirstURL});contextParts.push(`${stripHtml(item.Text)}\\nSource: ${item.FirstURL}`);} }
      }
    }catch(error){ console.warn("DuckDuckGo fallback failed",error); }
  }
  return {context:contextParts.join("\\n\\n").slice(0,14000),sources:sources.slice(0,6)};
}

export default { async fetch(request:Request,env:Env):Promise<Response>{
  const url=new URL(request.url); const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"};
  if(request.method==="OPTIONS")return new Response(null,{status:204,headers:cors});
  if(url.pathname==="/api/search"){
    if(request.method!=="POST")return new Response(JSON.stringify({error:"Method not allowed"}),{status:405,headers:{"Content-Type":"application/json",...cors}});
    try{const body:any=await request.json();const result=await webSearch(String(body?.query||""));return new Response(JSON.stringify(result),{status:200,headers:{"Content-Type":"application/json",...cors}});}catch(error){return new Response(JSON.stringify({error:String(error)}),{status:500,headers:{"Content-Type":"application/json",...cors}})}
  }
  if(url.pathname!=="/api/chat")return env.ASSETS.fetch(request);
  if(request.method!=="POST")return new Response(JSON.stringify({error:"Method not allowed"}),{status:405,headers:{"Content-Type":"application/json",...cors}});
  try{
    const body=await request.json() as RequestBody; const message=String(body.message||"").trim(); const language=String(body.language||"en"); const image=typeof body.image==="string"?body.image:"";
    if(!message&&!image)return new Response(JSON.stringify({error:"Message or image is required"}),{status:400,headers:{"Content-Type":"application/json",...cors}});
    const previous=Array.isArray(body.messages)?body.messages:[];
    const messages=previous.filter(m=>m&&(m.content||m.text)).slice(-20).map(m=>({role:m.role==="assistant"?"assistant":"user",content:String(m.content||m.text||"")}));
    const prompt=`You are Global AI Mahlet, a helpful, friendly and honest multilingual AI assistant. The user's selected language is: ${language}. Help users learn, solve problems, write, code, understand information and analyze images. Understand spelling and grammar mistakes. Use clear headings, bullets and steps when useful. When web search context is provided, use it for current facts and cite the supplied source URLs in the answer when relevant. Never claim live browsing when no web context is provided. For images, analyze only what is visible and never pretend to see unclear details.`;
    let webSources:Array<{title:string,url:string}>=[]; let webContext="";
    if(body.webSearch&&message){const result=await webSearch(message);webContext=result.context;webSources=result.sources;}
    const finalMessage=message+(webContext?`\\n\\nWEB SEARCH RESULTS — use these current results as evidence. Sources:\\n${webContext}`:"");
    let result:any;
    if(image){const imageUrl=image.startsWith("data:")?image:`data:image/jpeg;base64,${image}`; result=await env.AI.run("@cf/google/gemma-4-26b-a4b-it",{messages:[{role:"system",content:prompt},{role:"user",content:[{type:"image_url",image_url:{url:imageUrl}},{type:"text",text:finalMessage||"Please analyze this image."}]}],max_tokens:1024,temperature:.6,chat_template_kwargs:{enable_thinking:false}});} else {if(!messages.length||messages[messages.length-1].content!==message)messages.push({role:"user",content:finalMessage});else messages[messages.length-1].content=finalMessage;result=await env.AI.run("@cf/google/gemma-4-26b-a4b-it",{messages:[{role:"system",content:prompt},...messages],max_tokens:1024,temperature:.6,chat_template_kwargs:{enable_thinking:false}});}
    const answer=result?.response||result?.result?.response||result?.choices?.[0]?.message?.content; if(!answer)throw new Error("Cloudflare AI returned no response");
    return new Response(JSON.stringify({text:String(answer),language,imageAnalyzed:Boolean(image),webSources}),{status:200,headers:{"Content-Type":"application/json",...cors}});
  }catch(error){return new Response(JSON.stringify({text:"I couldn't complete that request right now.",error:error instanceof Error?error.message:String(error)}),{status:500,headers:{"Content-Type":"application/json",...cors}})}
}};
