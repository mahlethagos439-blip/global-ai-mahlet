GLOBAL AI MAHLET — FIXED VERSION

Replace these two files in your GitHub project:

  public/index.html  <- this package's public/index.html
  src/index.ts       <- this package's src/index.ts

Keep your existing wrangler configuration and AI binding named AI.

Fixes in this version:
- Send clears the composer immediately.
- A late image resize/load callback cannot put the photo back into the composer after Send.
- The sent photo appears in the conversation immediately.
- Image understanding uses Gemma 4 26B A4B with streaming, so the answer can start appearing before the full response finishes.
- Large images are compressed in the browser before upload to reduce transfer time.
- Offline selected photos show a red retry button.
- Real web search is available through /api/search and source links are shown under search answers.
- Search intent includes explicit requests such as search, look up, find online, browse, latest, current, news, and sources.
- The existing Gemma image-analysis model and image input format are preserved.
- The interface keeps the existing 100 language choices.
