interface Fetcher { fetch(request: Request): Promise<Response>; }

interface Env {
  AI: Ai;
  ASSETS: Fetcher;
}

interface Ai {
  run(
    model: string,
    inputs: Record<string, unknown>,
    options?: Record<string, unknown>
  ): Promise<any>;
}

interface ChatMessage {
  role?: string;
  content?: string;
  text?: string;
}

interface RequestBody {
  message?: string;
  language?: string;
  image?: string;
  messages?: ChatMessage[];
  webSearch?: boolean;
}

function json(data: unknown, status = 200, corsHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
      ...corsHeaders
    }
  });
}

function stripHtml(value: string): string {
  return value
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/\s+/g, " ")
    .trim();
}

function decodeUrl(value: string): string {
  const cleaned = value.replace(/&amp;/g, "&");
  try {
    const url = new URL(cleaned, "https://html.duckduckgo.com");
    const redirected = url.searchParams.get("uddg");
    return redirected ? decodeURIComponent(redirected) : url.toString();
  } catch {
    return cleaned;
  }
}

async function webSearch(query: string) {
  const q = query.trim();
  if (!q) return { context: "", sources: [] as Array<{ title: string; url: string }> };

  const sources: Array<{ title: string; url: string }> = [];
  const contextParts: string[] = [];

  try {
    const url = "https://html.duckduckgo.com/html/?q=" + encodeURIComponent(q);
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; Global-AI-Mahlet/1.0; +https://global-ai-mahlet.pages.dev/)"
      }
    });

    if (response.ok) {
      const html = await response.text();
      const resultRe = /<div[^>]*class="result"[\s\S]*?<\/div>\s*<\/div>/gi;
      const blocks = html.match(resultRe) || [];

      for (const block of blocks) {
        const linkMatch = block.match(/<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
        if (!linkMatch) continue;
        const sourceUrl = decodeUrl(linkMatch[1]);
        if (!/^https?:\/\//i.test(sourceUrl)) continue;

        const title = stripHtml(linkMatch[2]) || "Web result";
        const snippetMatch = block.match(/<a[^>]*class="result__snippet"[^>]*>[\s\S]*?<\/a>/i) || block.match(/<div[^>]*class="result__snippet"[^>]*>([\s\S]*?)<\/div>/i);
        const snippet = snippetMatch ? stripHtml(snippetMatch[1] || snippetMatch[0]) : "";

        if (!sources.some(item => item.url === sourceUrl)) {
          sources.push({ title, url: sourceUrl });
          contextParts.push(`${title}\n${snippet}\nSource: ${sourceUrl}`.trim());
        }
        if (sources.length >= 6) break;
      }
    }
  } catch (error) {
    console.warn("DuckDuckGo HTML search failed:", error);
  }

  // Fallback to DuckDuckGo's public instant-answer endpoint when HTML results
  // are unavailable. This is still live internet data, but may return fewer results.
  if (!sources.length) {
    try {
      const url = "https://api.duckduckgo.com/?q=" + encodeURIComponent(q) + "&format=json&no_html=1&skip_disambig=1&no_redirect=1";
      const response = await fetch(url, {
        headers: { "User-Agent": "Global-AI-Mahlet/1.0" }
      });
      if (response.ok) {
        const data: any = await response.json();
        if (data.AbstractURL && (data.AbstractText || data.Heading)) {
          sources.push({ title: data.Heading || "Web result", url: data.AbstractURL });
          contextParts.push(`${data.Heading || "Web result"}\n${data.AbstractText || ""}\nSource: ${data.AbstractURL}`.trim());
        }
        for (const item of Array.isArray(data.RelatedTopics) ? data.RelatedTopics : []) {
          if (item?.FirstURL && item?.Text && sources.length < 6) {
            sources.push({ title: stripHtml(item.Text).slice(0, 180), url: item.FirstURL });
            contextParts.push(`${stripHtml(item.Text)}\nSource: ${item.FirstURL}`);
          }
        }
      }
    } catch (error) {
      console.warn("DuckDuckGo instant-answer search failed:", error);
    }
  }

  return {
    context: contextParts.join("\n\n").slice(0, 14000),
    sources: sources.slice(0, 6)
  };
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (url.pathname === "/api/search") {
      if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, corsHeaders);
      try {
        const body = await request.json() as { query?: string };
        const query = String(body.query || "").trim();
        if (!query) return json({ error: "Search query is required" }, 400, corsHeaders);
        const result = await webSearch(query);
        return json(result, 200, corsHeaders);
      } catch (error) {
        return json({ error: error instanceof Error ? error.message : String(error) }, 500, corsHeaders);
      }
    }

    if (url.pathname !== "/api/chat") {
      return env.ASSETS.fetch(request);
    }

    if (request.method !== "POST") {
      return json({ error: "Method not allowed" }, 405, corsHeaders);
    }

    try {
      const body = await request.json() as RequestBody;
      const message = String(body.message || "").trim();
      const language = String(body.language || "en");
      const image = typeof body.image === "string" ? body.image : "";
      const webSearchRequested = Boolean(body.webSearch);

      if (!message && !image) {
        return json({ error: "Message or image is required" }, 400, corsHeaders);
      }

      const previousMessages = Array.isArray(body.messages) ? body.messages : [];
      const messages = previousMessages
        .filter(m => m && (m.content || m.text))
        .slice(-20)
        .map(m => ({
          role: m.role === "assistant" ? "assistant" : "user",
          content: String(m.content || m.text || "")
        }));

      const systemPrompt = `
You are Global AI Mahlet, a helpful, friendly and honest multilingual AI assistant.

The user's selected language is:
${language}

Understand the user's intended meaning even when their English or other language has spelling,
grammar, punctuation, or typing mistakes. Do not criticize their writing unless they ask you to.
Answer naturally, clearly, and beautifully.

Use readable structure whenever useful: short paragraphs, headings, bullet points, numbered steps,
tables, examples, and spacing. Avoid one giant wall of text. Make answers comfortable to read on a phone.
Explain step by step when the user asks how to do something or when detail is needed.

When the user sends an image, actually analyze it. Describe only what can reasonably be seen.
If the image contains text, read the visible text carefully. If it is unclear, say so.
Never pretend to see something that is not visible.

If WEB SEARCH CONTEXT is supplied, treat it as live web research. Use it for current or web-search
questions, distinguish source facts from your own explanation, and never invent source URLs.
The interface will display the source links separately.

You are an AI assistant. Be honest about that.
`;

      let result: any;

      if (image) {
        const imageUrl = image.startsWith("data:") ? image : `data:image/jpeg;base64,${image}`;
        const userContent: any[] = [
          { type: "image_url", image_url: { url: imageUrl } },
          { type: "text", text: message || "Please analyze this image and explain what you see clearly." }
        ];

        result = await env.AI.run("@cf/google/gemma-4-26b-a4b-it", {
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userContent }
          ],
          // Stream image understanding so the browser can show the answer
          // as soon as Gemma starts generating it. A shorter cap also keeps
          // image answers focused and reduces time to completion.
          max_tokens: 640,
          temperature: 0.4,
          stream: true,
          chat_template_kwargs: { enable_thinking: false }
        }, { rejectIfBusy: true });

        // Workers AI supports SSE streaming for Gemma 4. Forward the stream
        // directly instead of buffering the whole image-analysis response.
        if (result && typeof result.getReader === "function") {
          return new Response(result, {
            status: 200,
            headers: {
              "Content-Type": "text/event-stream; charset=UTF-8",
              "Cache-Control": "no-cache, no-transform",
              "Connection": "keep-alive",
              ...corsHeaders
            }
          });
        }
      } else {
        let finalMessage = message;
        let sources: Array<{ title: string; url: string }> = [];

        if (webSearchRequested) {
          const web = await webSearch(message);
          if (web.context) {
            finalMessage += `\n\nWEB SEARCH CONTEXT:\n${web.context}`;
          }
          sources = web.sources;
        }

        if (!messages.length || messages[messages.length - 1].content !== message) {
          messages.push({ role: "user", content: finalMessage });
        } else if (webSearchRequested && messages[messages.length - 1].content === message) {
          messages[messages.length - 1].content = finalMessage;
        }

        result = await env.AI.run("@cf/google/gemma-4-26b-a4b-it", {
          messages: [
            { role: "system", content: systemPrompt },
            ...messages
          ],
          max_tokens: 1024,
          temperature: 0.6,
          chat_template_kwargs: { enable_thinking: false }
        });

        const answer = result?.response || result?.result?.response || result?.choices?.[0]?.message?.content;
        if (!answer) throw new Error("Cloudflare AI returned no response");

        return json({
          text: String(answer),
          language,
          imageAnalyzed: false,
          webSources: sources
        }, 200, corsHeaders);
      }

      const answer = result?.response || result?.result?.response || result?.choices?.[0]?.message?.content;
      if (!answer) throw new Error("Cloudflare AI returned no response");

      return json({
        text: String(answer),
        language,
        imageAnalyzed: Boolean(image),
        webSources: []
      }, 200, corsHeaders);
    } catch (error) {
      console.error("Global AI Mahlet Worker error:", error);
      return json({
        text: "I couldn't complete that request right now.",
        error: error instanceof Error ? error.message : String(error)
      }, 500, corsHeaders);
    }
  }
};
