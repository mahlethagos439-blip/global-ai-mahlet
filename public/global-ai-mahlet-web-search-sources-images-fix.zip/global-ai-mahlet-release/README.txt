GLOBAL AI MAHLET — WEB SEARCH + SOURCES + RELEVANT IMAGES

Files to replace in your Cloudflare project:
1. public/index.html  -> replace your current public/index.html
2. src/index.ts       -> replace your current src/index.ts

What this update adds:
- Real live web search through Cloudflare AI Gateway / OpenAI web_search_preview.
- Text questions use web search by default so answers can show real sources.
- Source cards show source/site name, article title, clickable URL, domain, and an image/logo when available.
- Relevant article images (og:image/twitter:image) are shown above the source cards when available.
- No fake sources are created if the search provider returns none.
- Existing chat, image upload, voice, memory, business workspace, analytics, languages, and recent chats are preserved.

IMPORTANT:
- Your Worker must have the AI binding named AI.
- Your Worker/Gateway must have access to the OpenAI web search tool as configured by Cloudflare.
- Web search is billed by the upstream provider according to Cloudflare's current AI Gateway web-search pricing.

DEPLOY:
Upload/commit these two files to the same repository paths, then wait for Cloudflare to build and deploy.
