interface Fetcher { fetch(request: Request): Promise<Response>; }

interface Env {
  AI: Ai;
  ASSETS: Fetcher;
  ANALYTICS?: AnalyticsEngineDataset;
}

interface AnalyticsEngineDataset {
  writeDataPoint(data: {
    blobs?: string[];
    doubles?: number[];
    indexes?: string[];
  }): void;
}

interface Ai {
  run(
    model: string,
    inputs: Record<string, unknown>,
    options?: Record<string, unknown>
  ): Promise<any>;
}

interface ChatMessage {
  role?: string;
  content?: string;
  text?: string;
}

interface RequestBody {
  message?: string;
  language?: string;
  image?: string;
  imageName?: string;
  messages?: ChatMessage[];
  memories?: MemoryItem[];
  businessProfile?: BusinessProfile;
  webSearch?: boolean;
  event?: string;
}

interface MemoryItem {
  id?: string;
  text?: string;
}

interface BusinessProfile {
  company?: string;
  role?: string;
  goal?: string;
  tone?: string;
}

interface WebSource {
  title: string;
  url: string;
  domain: string;
  image?: string;
  icon?: string;
}


const SEARCH_MODEL = "openai/gpt-4o-mini";
const TEXT_MODEL = "@cf/meta/llama-3.1-8b-instruct-fast";
const VISION_MODEL = "@cf/meta/llama-3.2-11b-vision-instruct";

function json(data: unknown, status = 200, headers: Record<string,string> = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {"Content-Type":"application/json", ...headers}
  });
}

function recordEvent(env: Env, event: string, path: string, ok = true) {
  try {
    env.ANALYTICS?.writeDataPoint({
      indexes: [event.slice(0,96), path.slice(0,96)],
      blobs: [ok ? "ok" : "error"],
      doubles: [1]
    });
  } catch {}
}

function safeUrl(value: unknown): string {
  if (typeof value !== "string" || !value) return "";
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:" ? u.toString() : "";
  } catch { return ""; }
}

function domainOf(value: string): string {
  try { return new URL(value).hostname.replace(/^www\./i,""); }
  catch { return value; }
}

function extractBase64Image(value: string): string {
  const match = value.match(/^data:image\/[^;]+;base64,(.+)$/s);
  return match ? match[1] : value;
}

function extractWebSearchSources(result: any): WebSource[] {
  const out: WebSource[] = [];
  const seen = new Set<string>();
  const add = (title: unknown, rawUrl: unknown) => {
    const url = safeUrl(rawUrl);
    if (!url || seen.has(url)) return;
    seen.add(url);
    out.push({
      title: typeof title === "string" && title.trim() ? title.trim() : domainOf(url),
      url,
      domain: domainOf(url)
    });
  };
  const output = Array.isArray(result?.output)
    ? result.output
    : Array.isArray(result?.result?.output) ? result.result.output : [];
  for (const item of output) {
    const annotations = item?.content?.flatMap?.((part: any) =>
      Array.isArray(part?.annotations) ? part.annotations : []
    ) || [];
    for (const annotation of annotations) {
      add(annotation?.title || annotation?.text, annotation?.url);
    }
    if (item?.type === "web_search_call") {
      const results = item?.action?.sources || item?.action?.results || [];
      if (Array.isArray(results)) {
        for (const source of results) add(source?.title, source?.url);
      }
    }
  }
  return out.slice(0,10);
}

function metaValue(html: string, key: string): string {
  const k = key.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  const patterns = [
    new RegExp(`<meta[^>]+(?:property|name)=["']${k}["'][^>]+content=["']([^"']+)["'][^>]*>`,"i"),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${k}["'][^>]*>`,"i")
  ];
  for (const p of patterns) {
    const m = html.match(p);
    if (m?.[1]) return m[1].trim();
  }
  return "";
}

async function enrichSource(source: WebSource): Promise<WebSource> {
  try {
    const response = await fetch(source.url, {
      redirect: "follow",
      headers: {
        "User-Agent":"Mozilla/5.0 (compatible; GlobalAIMahlet/1.0)",
        "Accept":"text/html,application/xhtml+xml"
      }
    });
    if (!response.ok || !(response.headers.get("content-type") || "").includes("text/html")) {
      return source;
    }
    const html = (await response.text()).slice(0,300000);
    const title = metaValue(html,"og:title") || metaValue(html,"twitter:title") || source.title;
    const rawImage = metaValue(html,"og:image") || metaValue(html,"twitter:image");
    let image = "";
    if (rawImage) {
      try { image = new URL(rawImage, source.url).toString(); } catch {}
    }
    return {...source, title, ...(image ? {image} : {})};
  } catch {
    return source;
  }
}

async function enrichSources(sources: WebSource[]): Promise<WebSource[]> {
  const enriched = await Promise.all(sources.slice(0,8).map(enrichSource));
  return enriched.map(source => ({
    ...source,
    icon:`https://icons.duckduckgo.com/ip3/${encodeURIComponent(source.domain)}.ico`
  }));
}

function looksTimeSensitive(text: string): boolean {
  return /\b(latest|today|now|current|currently|recent|news|this week|this month|price|prices|exchange rate|weather|score|scores|schedule|online|internet|web search|search|look up|browse|source|sources)\b/i.test(text);
}

export default {
  async fetch(
    request: Request,
    env: Env
  ): Promise<Response> {

    const url = new URL(request.url);

    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders
      });
    }

    if (!url.pathname.startsWith("/api/")) {
      return env.ASSETS.fetch(request);
    }

    if (request.method !== "POST") {
      return new Response(
        JSON.stringify({
          error: "Method not allowed"
        }),
        {
          status: 405,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders
          }
        }
      );
    }

    try {

      const body =
        await request.json() as RequestBody;

      if (url.pathname === "/api/analytics") {
        recordEvent(env, String(body.event || "unknown"), url.pathname, true);
        return json({ok:true}, 200, corsHeaders);
      }

      if (url.pathname !== "/api/chat" && url.pathname !== "/api/search") {
        return json({error:"Not found"}, 404, corsHeaders);
      }

      const message =
        String(body.message || "").trim();

      const language =
        String(body.language || "en");

      const image =
        typeof body.image === "string"
          ? body.image
          : "";

      // Global AI Mahlet uses live web search for every text question by default,
      // so answers can be accompanied by real, clickable sources. Image-only
      // requests continue through the vision model.
      const webSearch =
        Boolean(message) &&
        !image &&
        (body.webSearch !== false);

      if (!message && !image) {
        return new Response(
          JSON.stringify({
            error: "Message or image is required"
          }),
          {
            status: 400,
            headers: {
              "Content-Type": "application/json",
              ...corsHeaders
            }
          }
        );
      }

      const previousMessages =
        Array.isArray(body.messages)
          ? body.messages
          : [];

      const messages =
        previousMessages
          .filter(
            m =>
              m &&
              (m.content || m.text)
          )
          .slice(-20)
          .map(m => ({
            role:
              m.role === "assistant"
                ? "assistant"
                : "user",

            content:
              String(
                m.content ||
                m.text ||
                ""
              )
          }));

      const memories = Array.isArray(body.memories)
        ? body.memories.map(m => String(m?.text || "").trim()).filter(Boolean).slice(0,20)
        : [];

      const bp = body.businessProfile || {};
      const businessContext = [
        bp.company ? `Company: ${String(bp.company).slice(0,200)}` : "",
        bp.role ? `Role: ${String(bp.role).slice(0,200)}` : "",
        bp.goal ? `Business goal: ${String(bp.goal).slice(0,500)}` : "",
        bp.tone ? `Preferred business tone: ${String(bp.tone).slice(0,100)}` : ""
      ].filter(Boolean).join("\n");

      const memoryContext = memories.length
        ? `User-controlled memory. Use only when relevant:\n- ${memories.join("\n- ")}`
        : "No saved user-controlled memory was provided.";

      const systemPrompt = `
You are Global AI Mahlet, a warm, useful, honest multilingual AI assistant.

Selected language: ${language}
Respond in that language whenever practical.

${memoryContext}

${businessContext ? `Business Workspace:\n${businessContext}` : "No Business Workspace context was provided."}

Rules:
- Help with learning, coding, writing, planning, business, research, problem solving, and image understanding.
- Give the answer first and use headings, bullets, numbered steps, tables, examples, and short paragraphs when useful.
- Do not force decorative formatting into every answer.
- Never invent facts, citations, URLs, sources, or images.
- When live web search is used, base current claims on retrieved web information.
- When an image is supplied, analyze only what can actually be observed and read visible text when possible.
- If an image is unclear, say what cannot be determined.

Web rules:
- When web search is enabled, use the live web-search tool.
- Prefer authoritative and primary sources when possible.
- Use multiple sources when useful.
- The application will display the source cards and relevant source images returned by the search.
`;
      let result: any;
      let sources: WebSource[] = [];

      if (webSearch && !image) {
        recordEvent(env, "web_search", url.pathname, true);

        result = await env.AI.run(
          SEARCH_MODEL,
          {
            input: [
              {
                role: "system",
                content: systemPrompt +
                  "\nUse live web search now. Answer from the sources actually retrieved."
              },
              { role: "user", content: message }
            ],
            max_output_tokens: 1800,
            tools: [{type:"web_search_preview"}]
          },
          {gateway:{id:"default"}}
        );

        sources = await enrichSources(extractWebSearchSources(result));
      } else if (image) {
        recordEvent(env, "image_analysis", url.pathname, true);

        result = await env.AI.run(
          VISION_MODEL,
          {
            messages: [
              {role:"system", content:systemPrompt},
              ...messages
            ],
            image: extractBase64Image(image),
            max_tokens: 1200,
            temperature: 0.4
          }
        );
      } else {
        recordEvent(env, "chat", url.pathname, true);

        result = await env.AI.run(
          TEXT_MODEL,
          {
            messages: [
              {role:"system", content:systemPrompt},
              ...messages
            ],
            max_tokens: 1200,
            temperature: 0.6
          }
        );
      }

      const answer =
        result?.response ||
        result?.result?.response ||
        result?.choices?.[0]?.message?.content ||
        result?.output_text ||
        result?.result?.output_text ||
        result?.output?.find?.((item:any)=>item?.type==="message")
          ?.content?.find?.((part:any)=>part?.type==="output_text")?.text;

      if (!answer) {
        throw new Error("Cloudflare AI returned no response");
      }

      const answerImages = sources
        .filter(source => Boolean(source.image))
        .slice(0,4)
        .map(source => ({
          url: source.image,
          title: source.title,
          sourceUrl: source.url,
          domain: source.domain
        }));

      return json(
        {
          text:String(answer),
          language,
          imageAnalyzed:Boolean(image),
          webSearchUsed:Boolean(webSearch && !image),
          sources,
          answerImages
        },
        200,
        corsHeaders
      );

    } catch (error) {
      console.error("Global AI Mahlet Worker error:", error);
      recordEvent(env, "request_error", url.pathname, false);
      return json(
        {
          text:"Global AI Mahlet could not complete that request right now.",
          error:error instanceof Error ? error.message : String(error)
        },
        500,
        corsHeaders
      );
    }
  }
};
